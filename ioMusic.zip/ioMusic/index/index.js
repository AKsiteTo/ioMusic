var mp3Url = null;
var playMusic = 0;
var flag = 0;
var getStorageName = localStorage.getItem("NameList")
var lStorageName = "";
var lStorageNameList = JSON.parse(getStorageName);
var getclickhistory = JSON.parse(localStorage.getItem("history"))
var NameListJson;
var live;
var OO;
var BB = [];
var lStorage;
var Jsons;
var play = 0;
var plays = 0;
var cheatingIndexs = 0;
var timer;
var MusicTimetwo;
var musicIndex;
var searchSongArr = JSON.parse(localStorage.getItem("history"));
var advanceAndBack = 0;
var Longer = 0;
var _time = 0;
var _flex = 0;
var lyricsElements;
var timeList = [];
var lyricTime;
var clock = 0;
//时间对比
var contrast = 0;
//时间格式化
var sec = 0;
var minsec = 0;
var minute = 0;
var formatting = 0;
var songLength = 0;
var setData = {};
var playAllSongList_data = [];
var realtimeupdate = {}

new Vue({
    el: "#app",
    data: {
        text: "sjda",
        change1: true,
        change2: false,
        songList: [],
        radioList: [],
        searchList: [],
        hotSongs: [],
        test: [1, 3, 1, 2, 1, 1, 1, 1, 1, 1, 2],
        searchInput: "",
        onSongList: [],
        love: "https://vkceyugu.cdn.bspapp.com/VKCEYUGU-bdc308e2-389d-4bcf-8905-c5a9e788f096/82cec79f-9089-4991-9dc2-d28662426dea.png",
        judgeOne: true,
        judgeTwo: false,
        playList: BB,
        playUrlT: "https://vkceyugu.cdn.bspapp.com/VKCEYUGU-bdc308e2-389d-4bcf-8905-c5a9e788f096/f238a0af-941e-4112-934e-39a7cf87d968.png",
        rightBottomPic: "https://vkceyugu.cdn.bspapp.com/VKCEYUGU-bdc308e2-389d-4bcf-8905-c5a9e788f096/71549260-3590-40ab-b4c9-e9cddd7798ee.png",
        rightBottomSongName: "还没有歌曲",
        rightBottomSongerName: "",
        deleShow: true,
        Longer: 0,
        songTime: 0,
        songMinute: 0,
        getuploadsearch: [],
        songCI: [],
        slidingBarMovePX: 0,
        value1: 50,
        isErr: false,
        flexTimer: 0,
        songListDetail: {},
        songAllList: [],
        bannerCircle: [
            {
                title: "",
                banner: "index/1b8fa233c6c74b6e85dfac46067aed32.png",
                circleId: "",
                slogan: "令人放松的",
                color: " #fff"

            },
            {
                title: "",
                banner: "index/bannerBlack.jpg",
                circleId: "",
                slogan: "令人愉悦的",
                color: " #1c1f1e"
            },
            {
                title: "",
                banner: "index/banner10.jpg",
                circleId: "",
                slogan: "令人欢欣的",
                color: " #1c1f1e"
            }
        ],
        bannerWhite: false
    },
    methods: {
        search() {
            this.change1 = true;
            this.change2 = false;
        },
        home() {
            this.change1 = false;
            this.change2 = true;
            songListPage.style.top = "660px";
        },
        swichLove() {
            this.love = "https://vkceyugu.cdn.bspapp.com/VKCEYUGU-bdc308e2-389d-4bcf-8905-c5a9e788f096/30c51759-ff2a-4cb9-8ed4-69ea8985a6b2.png"
        },

        //请求歌单
        reqSongList(songListId) {
            var that = this;
            axios.get("http://localhost:3000/playlist/detail?id=" + songListId)
                .then(response => {
                    console.log(response);
                    that.songListDetail = response.data.playlist;
                    that.songListDetail.description = that.songListDetail.description.length > 80 ? that.songListDetail.description.slice(0, 80) + "...." : that.songListDetail.description;
                })
        },
        //歌单里面播放所有歌曲
        playAllSongList() {
            this.cleanAllSong()
            console.log(playAllSongList_data.length);

            for (i = 0; i < playAllSongList_data.length; i++) {

                lStorage = this.dataStorage(playAllSongList_data[i].name, playAllSongList_data[i].ar[0].name, playAllSongList_data[i].al.picUrl, playAllSongList_data[i].fee, playAllSongList_data[i].dt, playAllSongList_data[i].id);
                lStorageName = playAllSongList_data[i].name + "-" + playAllSongList_data[i].ar[0].name

                lStorageNameList.push(lStorageName)
                NameListJson = JSON.stringify(lStorageNameList)
                localStorage.setItem("NameList", NameListJson)
                Jsons = JSON.stringify(lStorage)
                localStorage.setItem(lStorageName, Jsons);

                //实时更新右侧状态
                realtimeupdate = this.dataStorage(playAllSongList_data[i].name, playAllSongList_data[i].ar[0].name, playAllSongList_data[i].al.picUrl, playAllSongList_data[i].fee, playAllSongList_data[i].dt, playAllSongList_data[i].id);
                this.playList.push(realtimeupdate)
                this.songTime = this.playList.length
                this.songminute()
            }
            this.playSongUrl(playAllSongList_data[0].al.picUrl, playAllSongList_data[0].name, playAllSongList_data[0].ar[0].name, 0, playAllSongList_data[0].dt, playAllSongList_data[0].fee, playAllSongList_data[0].id)

        },
        //数据层
        dataStorage(musicName, musicSong, MusicUrl, fee, MusicTime, musicId) {
            return {
                musicName: musicName,
                musicSong: musicSong,
                MusicUrl: MusicUrl,
                fee: fee,
                MusicTime: MusicTime,
                musicId: musicId
            }
        },
        //校园圈圈
        switchBanner(num) {
            this.flexTimer = num
            for (i = 0; i < 3; i++) {
                this.bannerCircle[i].color = "#1c1f1e"
            }
            this.bannerCircle[num].color = "#fff"

        },
        //请求歌单所有歌曲
        reqAllSong(songListId) {
            var that = this;
            axios.get("http://localhost:3000/playlist/track/all?id=" + songListId + "&limit=10&offset=1")
                .then(response => {
                    that.songAllList = response.data.songs
                    for (i = 0; i < that.songAllList.length; i++) {
                        that.songAllList[i].dt = (Math.floor(that.songAllList[i].dt / 1000 / 60)) + ":" + Math.floor((that.songAllList[i].dt / 1000) % 60)
                        if (that.songAllList[i].fee == 1) {
                            that.songAllList[i].dt = "0:30"
                        }
                    }
                })
            axios.get("http://localhost:3000/playlist/track/all?id=" + songListId + "&limit=10&offset=1")
                .then(response => {
                    console.log(response.data.songs);

                    playAllSongList_data = response.data.songs.slice(0, response.data.songs.length)
                })

        },
        // banner图的定时器


        bannerTimer() {
            var that = this

            setInterval(() => {
                for (i = 0; i < 3; i++) {
                    that.bannerCircle[i].color = "#1c1f1e"
                }
                that.flexTimer++

                that.bannerWhite = true;
                setTimeout(() => {
                    that.bannerWhite = false;
                }, 200)
                if (that.flexTimer == 3) {
                    that.flexTimer = 0
                }
                that.bannerCircle[that.flexTimer].color = "#fff"
            }, 5000)
        },

        //banner图上面查看详细
        viewDetailed() {
            this.songListBlock(this.bannerCircle[this.flexTimer].circleId)
        },

        //歌单详细页面
        songListBlock(songListId) {
            songListPage.style.top = "0px";
            this.reqSongList(songListId)
            this.reqAllSong(songListId)
        },
        songListNone() {
            songListPage.style.top = "660px";
        },

        //清空所有歌曲
        cleanAllSong() {
            this.playList = [];
            localStorage.removeItem("NameList");
            for (i = 0; i < lStorageNameList.length; i++) {
                localStorage.removeItem(lStorageNameList[i])

            }
            localStorage.removeItem("NameList")
            lStorageNameList = []
            this.songTime = 0;
            this.songMinute = 0;
        },
        //时间格式化函数
        formatTime(clock) {
            minsec = clock % 100 % 10;
            sec = clock >= 10 ? Math.floor(clock / 10) : 0;
            sec = sec >= 60 ? sec % 60 : sec;
            sec = sec >= 10 ? sec : "0" + sec
            minute = Math.floor(clock / 600);
            minute = minute >= 10 ? minute : "0" + minute;
            formatting = minute + ":" + sec + "." + minsec;
            return formatting
        },
        //遍历列表
        hotRigrt() {
            setTimeout(() => {
                if (lStorageNameList == null) {
                    lStorageNameList = [];
                }
                for (i = 0; i < lStorageNameList.length; i++) {
                    var TT = lStorageNameList[i];
                    live = localStorage.getItem(TT);
                    OO = JSON.parse(live);
                    BB[i] = OO;
                }
                this.songTime = lStorageNameList.length
                this.songminute()
            }, 100)
        },
        //网络请求库
        axiosPlease() {
            var that = this;
            //请求歌单
            setTimeout(() => {
                axios.get("http://localhost:3000/personalized")
                    .then(response => {
                        console.log(response);
                        var splices = response.data.result;
                        for (i = 0; i < splices.length; i++) {
                            splices[i].name = splices[i].name.length > 14 ? splices[i].name.slice(0, 14) + "..." : splices[i].name;
                        }
                        that.songList = splices.slice(0, 5);
                        for (i = 0; i < 3; i++) {
                            that.bannerCircle[i].title = splices[i + 5].name
                            that.bannerCircle[i].circleId = splices[i + 5].id

                        }

                    }),
                    //请求电台
                    axios.get("http://localhost:3000/personalized/djprogram")
                        .then(res => {
                            var arr = res.data.result
                            that.radioList = arr.slice(0, 4);
                        }),
                    //请求热门音乐
                    axios.get("http://localhost:3000/toplist/artist?type=1")
                        .then(res => {
                            var arr = res.data.list.artists
                            that.hotSongs = arr.slice(0, 10)
                        })
            }, 500)

        },

        //记录总时长
        songminute() {
            var Time = 0;
            for (i = 0; i < this.playList.length; i++) {
                Time += parseInt(this.playList[i].MusicTime)
            }
            this.songMinute = parseInt(Time / 1000 / 60)
        },

        //点击歌手头像搜索
        returnSongName(songName) {
            this.searchInput = songName
            this.searchSong()
        },

        //音乐播放定时器
        timers(MusicTime) {
            songLength = MusicTime
            timer = setInterval(() => {
                if (_flex == 1) {
                    /*   var currentTimes = (_time * MusicTime) / 1000
                      this.playMusic.currentTime = currentTimes.toFixed(1);
                      clock = currentTimes.toFixed(1) * 10
                      console.log(clock); */
                    for (i = 0; i < timeList.length; i++) {
                        if (timeList[i] == this.formatTime(clock)) {
                            contrast = i
                        }
                    }
                    this.Longer = _time * 100;
                    _flex = 0;
                    /*         console.log(currentTimes.toFixed(2)); */
                }
                this.Longer += 0.5;
                Longer = this.Longer
                this.slidingBarMovePX = Longer * 2.64;
                if (this.Longer >= 100) {
                    this.Longer = 0
                    this.playMusic.pause()
                    this.cheatingIndexRight()
                }

            }, MusicTime / 100 / 2)

        },
        //点击滑动的歌词实时返回index
        SongReturnsIndex(index) {
            var _time = timeList[index];
            var minute = parseInt(_time.slice(0, 3))
            var sec = parseInt(_time.slice(3, 6))
            var minsec = parseInt(_time.slice(6, 7))
            clock = (minute * 60 + sec) * 10 + minsec
            this.playMusic.currentTime = clock / 10
            contrast = index;
            this.Longer = ((clock * 100) / (songLength / 100));
            this.slidingBarMovePX = Longer * 2.64;
            this.scrollBar();
        },

        // 歌词页面滚动条事件
        scrollBar() {
            lyricsElements = document.querySelectorAll(".words-of-a-song-content-div span")
            clearInterval(lyricTime)
            lyricTime = setInterval(() => {
                lyricsElements = document.querySelectorAll(".words-of-a-song-content-div span")
                this.formatTime(clock)
                if (timeList[contrast - 1] == timeList[contrast]) {
                    contrast++
                }
                if (formatting == timeList[contrast]) {
                    for (i = 0; i < lyricsElements.length; i++) {
                        lyricsElements[i].style.color = "rgb(232 232 232)";
                    }
                    document.querySelector(".words-of-a-song-content").scrollTop = lyricsElements[contrast].offsetTop - 140;
                    lyricsElements[contrast].style.color = "rgb(0 134 187)"
                    contrast++;
                }
                clock++;
            }, 99)
        },

        //电台播放
        playRadio(RadioId, musicName, musicSong) {
            console.log(RadioId);
            this.playAudio(RadioId, musicName, musicSong)
        },

        //音乐播放事件
        musicPlay(musicUrl, MusicTime, fee) {
            clearInterval(timer)
            clearInterval(lyricTime)
            clock = 0
            this.Longer = 0;
            this.playMusic = new Audio(musicUrl);
            this.playMusic.play();
            MusicTimetwo = MusicTime
            if (fee == 1) {
                MusicTimetwo = 30000;
                this.timers(MusicTimetwo)
            }
            else {
                this.timers(MusicTime)
            }
        },
        //存储数据


        //点击歌曲准备播放事件
        playAudio(musicId, musicName, musicSong) {
            plays = 0
            contrast = 0
            this.slidingBarMovePX = 0
            this.getSongCI(musicId)
            const that = this;
            cheatingIndexs = 0;
            clearInterval(timer)
            clearInterval(lyricTime)
            that.rightBottomSongName = musicName;
            that.rightBottomSongerName = musicSong;
            if (flag >= 1) {
                that.playMusic.pause();
            }
            //歌曲播放准备
            axios.get("http://localhost:3000/song/url?id=" + musicId)
                .then(res => {
                    that.mp3Url = res.data.data[0].url;
                    flag++;
                    //歌曲详细
                    axios.get("http://localhost:3000/song/detail?ids=" + musicId)
                        .then(res => {
                            setTimeout(() => {
                                that.scrollBar()
                            }, 1000);
                            var MusicUrl = res.data.songs[0].al.picUrl;
                            var fee = res.data.songs[0].fee;
                            var MusicTime = res.data.songs[0].dt

                            var lStorageName = musicName + "-" + musicSong;
                            that.musicPlay(that.mp3Url, MusicTime, fee)
                            lStorageNameList.unshift(lStorageName)
                            NameListJson = JSON.stringify(lStorageNameList)
                            localStorage.setItem("NameList", NameListJson)
                            lStorage = {
                                musicName: musicName,
                                musicSong: musicSong,
                                MusicUrl: MusicUrl,
                                fee: fee,
                                MusicTime: MusicTime,

                                musicId: musicId
                            }
                            Jsons = JSON.stringify(lStorage)
                            localStorage.setItem(musicName + "-" + musicSong, Jsons);

                            play++;
                            that.rightBottomPic = MusicUrl;
                            if (play != 0) {
                                this.playUrlT = "https://vkceyugu.cdn.bspapp.com/VKCEYUGU-bdc308e2-389d-4bcf-8905-c5a9e788f096/c6237111-22dc-4fc7-99d0-552178e70507.png";
                            }

                            //实时更新右侧状态
                            var realtimeupdate = {
                                musicName: musicName,
                                musicSong: musicSong,
                                MusicUrl: MusicUrl,
                                fee: fee,
                                MusicTime: MusicTime,
                                mp3Url: that.mp3Url,
                                musicId: musicId,
                            };
                            that.playList.unshift(realtimeupdate)
                            this.songTime = this.playList.length
                            that.songminute()

                        }, err => {
                            this.error()
                        })
                }, err => {
                    this.error()
                })
        },

        //错误处理
        error() {
            this.isErr = true;
            setTimeout(() => {
                this.isErr = false;
            }, 2000);
        },

        //点击历史搜索事件跳转到对应的搜索页面
        clickhistory(item) {
            advanceAndBack++;
            this.searchInput = item
            this.searchSong();
            if (searchSongArr.length == 0) {

            } else {
                searchSongArr.shift();
                var uploadsearchSongArr = JSON.stringify(searchSongArr)
                localStorage.setItem("history", uploadsearchSongArr)
            }
        },

        //伪造AJAX
        forgeAJAX() {
            var that = this;
            axios.get("http://localhost:3000/cloudsearch?keywords=" + this.searchInput)
                .then(res => {
                    console.log(res);
                    that.onSongList = res.data.result.songs
                    this.judgeOne = false;
                    this.judgeTwo = true;
                }, err => {
                    this.error();
                    console.log(err);
                })
        },
        /* 搜索歌曲事件 */
        searchSong() {
            advanceAndBack++;
            this.forgeAJAX();
            if (searchSongArr == null) {
                searchSongArr = []
                searchSongArr.unshift(this.searchInput)
                var uploadsearchSongArr = JSON.stringify(searchSongArr)
                localStorage.setItem("history", uploadsearchSongArr)
            } else {
                searchSongArr.unshift(this.searchInput)
                var uploadsearchSongArr = JSON.stringify(searchSongArr)
                localStorage.setItem("history", uploadsearchSongArr)
            }
            this.searchInput = "";


        },
        songListPageNone() {
            songListPage.style.top = "660px";
        },
        //渲染历史搜索
        uploadsearch() {
            this.getuploadsearch = searchSongArr
        },
        //返回页面
        returnLeft() {
            if (advanceAndBack < 1) {
                return;
            }
            this.judgeOne = true;
            this.judgeTwo = false;
            this.getuploadsearch = searchSongArr
        },
        returnRight() {
            if (advanceAndBack < 1) {
                return;
            }
            this.judgeOne = false;
            this.judgeTwo = true;
        },

        //播放右侧播放列表里面的歌曲
        playSongUrl(Mul, Mname, Msong, cheatingIndex, MusicTime, fee, musicId) {
            var that = this;
            this.slidingBarMovePX = 0
            clearInterval(timer)
            clearInterval(lyricTime)
            contrast = 0
            cheatingIndexs = cheatingIndex;
            musicIdSongCI = musicId;
            play++;
            if (play != 0) {
                this.playUrlT = "https://vkceyugu.cdn.bspapp.com/VKCEYUGU-bdc308e2-389d-4bcf-8905-c5a9e788f096/c6237111-22dc-4fc7-99d0-552178e70507.png";
                plays = 0
            }
            if (flag >= 1) {
                this.playMusic.pause();
            }
            axios.get("http://localhost:3000/song/url?id=" + musicId)
                .then(res => {
                    console.log(res);
                    var mp3Url = res.data.data[0].url;
                    that.musicPlay(mp3Url, MusicTime, fee)
                }, err => {
                    this.error
                })
            flag++;
            this.rightBottomPic = Mul;
            this.rightBottomSongName = Mname;
            this.rightBottomSongerName = Msong;
            this.getSongCI(musicId)
        },

        // 音乐播放与暂停
        palyAndPause() {
            clearInterval(timer)
            if (plays == 0) {
                this.playUrlT = "https://vkceyugu.cdn.bspapp.com/VKCEYUGU-bdc308e2-389d-4bcf-8905-c5a9e788f096/f238a0af-941e-4112-934e-39a7cf87d968.png";
                this.playMusic.pause();
                plays = 1
                clearInterval(lyricTime)
            } else {
                this.timers(MusicTimetwo)
                this.playUrlT = "https://vkceyugu.cdn.bspapp.com/VKCEYUGU-bdc308e2-389d-4bcf-8905-c5a9e788f096/c6237111-22dc-4fc7-99d0-552178e70507.png"
                plays = 0
                this.playMusic.play();
                this.scrollBar();
            }

        },

        //清空历史搜索
        empty() {
            searchSongArr = [];
            this.getuploadsearch = searchSongArr
            localStorage.removeItem("history")
        },
        //删除列表歌曲
        deleteMusic(musicIndex) {
            //不能取值重新赋值，下面这一块返回的是被删除掉的值，重新赋值取值会导致显示内容部队--数组API
            this.playList.splice(musicIndex, 1)
            this.deleShow = false;
            var deleteList = JSON.parse(localStorage.getItem("NameList"));
            var deleteName = deleteList[musicIndex]
            localStorage.removeItem(deleteName)
            deleteList.splice(musicIndex, 1)
            var setLiat = JSON.stringify(deleteList)
            localStorage.setItem("NameList", setLiat)
            lStorageNameList.splice(musicIndex, 1)
            this.songTime = this.playList.length
            this.songminute()
        },

        //切歌部分
        cheatingIndexLeft() {
            if (this.playUrlT == "https://vkceyugu.cdn.bspapp.com/VKCEYUGU-bdc308e2-389d-4bcf-8905-c5a9e788f096/f238a0af-941e-4112-934e-39a7cf87d968.png") {
                this.playUrlT = "https://vkceyugu.cdn.bspapp.com/VKCEYUGU-bdc308e2-389d-4bcf-8905-c5a9e788f096/c6237111-22dc-4fc7-99d0-552178e70507.png"
                plays = 0
            }
            var that = this
            this.playMusic.pause();
            clearInterval(timer)
            clearInterval(lyricTime)
            contrast = 0

            cheatingIndexs--;
            if (cheatingIndexs < 0) {
                cheatingIndexs = this.playList.length - 1
            }
            var MusicTime = this.playList[cheatingIndexs].MusicTime
            var fee = this.playList[cheatingIndexs].fee
            var MusicId = this.playList[cheatingIndexs].musicId
            this.rightBottomPic = this.playList[cheatingIndexs].MusicUrl
            this.rightBottomSongName = this.playList[cheatingIndexs].musicName,
                this.rightBottomSongerName = this.playList[cheatingIndexs].musicSong
            this.slidingBarMovePX = 0
            axios.get("http://localhost:3000/song/url?id=" + MusicId)
                .then(res => {
                    var mp3Url = res.data.data[0].url;
                    that.musicPlay(mp3Url, MusicTime, fee)
                }, err => {
                    this.error()
                })
            this.songminute();
            this.uploadsearch()
            this.getSongCI(MusicId);
        },
        cheatingIndexRight() {
            if (this.playUrlT == "https://vkceyugu.cdn.bspapp.com/VKCEYUGU-bdc308e2-389d-4bcf-8905-c5a9e788f096/f238a0af-941e-4112-934e-39a7cf87d968.png") {
                this.playUrlT = "https://vkceyugu.cdn.bspapp.com/VKCEYUGU-bdc308e2-389d-4bcf-8905-c5a9e788f096/c6237111-22dc-4fc7-99d0-552178e70507.png"
                plays = 0
            }
            var that = this
            this.playMusic.pause();
            clearInterval(timer)
            clearInterval(lyricTime)
            contrast = 0
            cheatingIndexs++;
            if (cheatingIndexs >= this.playList.length) {
                cheatingIndexs = 0;
            }
            var MusicTime = this.playList[cheatingIndexs].MusicTime
            var fee = this.playList[cheatingIndexs].fee
            var MusicId = this.playList[cheatingIndexs].musicId

            this.rightBottomPic = this.playList[cheatingIndexs].MusicUrl
            this.rightBottomSongName = this.playList[cheatingIndexs].musicName,
                this.rightBottomSongerName = this.playList[cheatingIndexs].musicSong,
                this.slidingBarMovePX = 0
            axios.get("http://localhost:3000/song/url?id=" + MusicId)
                .then(res => {
                    var mp3Url = res.data.data[0].url;
                    that.musicPlay(mp3Url, MusicTime, fee)
                }, err => {
                    this.error()
                })
            this.songminute()
            this.getSongCI(MusicId);
        },
        //获取歌词
        getSongCI(MusicId) {
            timeList.length = 0;
            this.songCI.length = 0;
            var that = this;
            axios.get("http://localhost:3000/lyric?id=" + MusicId)
                .then(res => {
                    c = res.data.lrc.lyric;
                    var d = c.split("\n")
                    /*      console.log(d); */
                    for (i = 0; i < d.length; i++) {
                        var songLength = d[i].length;
                        if (d[i].charAt(9) == "]") {
                            var _front = d[i].slice(0, 9)
                            var _back = d[i].slice(10, songLength);
                            d[i] = _front + "0]" + _back
                            var flex = d[i].slice(11, songLength + 1);
                        } else {
                            var flex = d[i].slice(11, songLength);
                        }
                        var list = d[i].slice(1, 8)
                        timeList[i] = list;
                        that.songCI[i] = flex;
                    }
                    setTimeout(function () {
                        that.scrollBar();
                    }, 100);
                }, err => {
                    console.log(err);
                })

        },
    },
    mounted: function () {

        if (lStorageNameList == null) {
            lStorageNameList = [];
        }
        this.axiosPlease()

        this.uploadsearch()
        this.songTime = this.playList.length
        this.bannerTimer()
        if (this.playList.length == 0) {

        } else {
            this.songminute()
        }
        this.hotRigrt()


    },
})

//歌单页面
var songListPage = document.querySelector(".song-list")
//歌词页面出现
var song = document.querySelector(".playPage-three-bottmo-first-img");
song.addEventListener("click", function () {
    document.querySelector(".words-of-a-song").style.transform = 'translateY(-600px)';
})
var wordsSong = document.querySelector(".wordsSong");
wordsSong.addEventListener("click", function () {
    document.querySelector(".words-of-a-song").style.transform = 'translateY(0px)';
})

//滚动条加载事件
/* var slidingBarDiv = document.querySelector(".slidingBarDiv")
var juli = Math.ceil(slidingBarDiv.getBoundingClientRect().left);
var slidingBarmove = document.querySelector(".slidingBarmove")
var slidingBar = document.querySelector(".slidingBar");
var flexs = 0;
var displacementDistance = 0
slidingBar.addEventListener("mousedown", function () {
    flexs = 0
    if (displacementDistance > 264) {
        displacementDistance = 264
    }
    if (displacementDistance < 0) {
        displacementDistance = 0
    }
    slidingBar.addEventListener("mousemove", function (e) {
        if (flexs == 1) {
            return;
        }
        displacementDistance = e.clientX - juli
        if (displacementDistance > 264) {
            displacementDistance = 264
        }
        if (displacementDistance < 0) {
            displacementDistance = 0
        }
        slidingBarmove.style.left = displacementDistance + "px"

    })
})
slidingBar.addEventListener("mouseup", function () {
    _flex = 1
    _time = (displacementDistance) / 264;
})
window.addEventListener("mouseup", function () {
    flexs = 1;
}) */

